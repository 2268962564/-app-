package io.github.myapp;

import android.app.Activity; import android.app.AlertDialog; import android.content.DialogInterface; import android.content.SharedPreferences; import android.content.pm.PackageManager; import android.content.res.AssetManager; import android.os.Build; import android.os.Bundle; import android.os.Environment; import android.text.InputType; import android.view.View; import android.widget.ArrayAdapter; import android.widget.Button; import android.widget.EditText; import android.widget.LinearLayout; import android.widget.Spinner; import android.widget.Toast;

import java.io.ByteArrayOutputStream; import java.io.File; import java.io.FileInputStream; import java.io.FileOutputStream; import java.io.IOException; import java.io.InputStream; import java.io.OutputStream; import java.net.URL; import java.net.URLConnection; import java.util.ArrayList;

public class MainActivity extends Activity { private Spinner spinnerFiles; private File targetDir; private File uploadDir; private SharedPreferences prefs;

	private static final int REQUEST_CODE = 123;
	private static final String PREFS_NAME = "ftp_settings";
	private static final String KEY_FTP_HOST = "ftp_host";
	private static final String KEY_FTP_USER = "ftp_user";
	private static final String KEY_FTP_PASS = "ftp_pass";
	private static final String KEY_LAST_FILE = "last_file";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		spinnerFiles = findViewById(R.id.spinner_files);
		Button btnGenerate = findViewById(R.id.btn_generate);
		Button btnUpload = findViewById(R.id.btn_upload);

		targetDir = new File(Environment.getExternalStoragePublicDirectory(
								 Environment.DIRECTORY_DOCUMENTS), "格机文件生成");
		uploadDir = new File(targetDir, "上传文件夹，请勿删除");
		prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
			if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
				requestPermissions(new String[]{
									   android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
									   android.Manifest.permission.READ_EXTERNAL_STORAGE
								   }, REQUEST_CODE);
			} else {
				ensureDirsAndRefresh();
			}
		} else {
			ensureDirsAndRefresh();
		}

		btnGenerate.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					generateScript();
				}
			});

		btnUpload.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					promptAndUpload();
				}
			});
	}

	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		if (requestCode == REQUEST_CODE) {
			if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
				ensureDirsAndRefresh();
			} else {
				Toast.makeText(this, "需要存储权限", Toast.LENGTH_LONG).show();
			}
		}
	}

	private void ensureDirsAndRefresh() {
		if (!targetDir.exists()) targetDir.mkdirs();
		if (!uploadDir.exists()) uploadDir.mkdirs();
		refreshSpinner();
	}

	private void refreshSpinner() {
		File[] files = targetDir.listFiles();
		ArrayList<String> list = new ArrayList<>();
		if (files != null) {
			for (File f : files) {
				if (f.isFile() && f.getName().endsWith(".sh")) list.add(f.getName());
			}
		}
		ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
														  android.R.layout.simple_spinner_item, list);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinnerFiles.setAdapter(adapter);

		String last = prefs.getString(KEY_LAST_FILE, null);
		if (last != null) {
			int idx = list.indexOf(last);
			if (idx >= 0) spinnerFiles.setSelection(idx);
		}
	}

	private void generateScript() {
		try {
			long ts = System.currentTimeMillis();
			String filename = ts + ".sh";
			File outFile = new File(targetDir, filename);

			AssetManager am = getAssets();
			// 写入 template.sh
			InputStream in1 = am.open("template.sh");
			FileOutputStream fos = new FileOutputStream(outFile);
			copyStream(in1, fos);
			in1.close(); fos.close();

			// 读取并替换变量
			String content;
			try {
				FileInputStream fis = new FileInputStream(outFile);
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				copyStream(fis, baos);
				fis.close();
				content = baos.toString("UTF-8");
				content = content.replace("${current_time}.sh", filename);
				FileOutputStream fout = new FileOutputStream(outFile);
				fout.write(content.getBytes("UTF-8"));
				fout.close();
			} catch (IOException e) {
				Toast.makeText(this, "替换失败: " + e.getMessage(), Toast.LENGTH_LONG).show();
				return;
			}

			// 追加 append.sh
			InputStream in2 = am.open("append.sh");
			FileOutputStream fos2 = new FileOutputStream(outFile, true);
			copyStream(in2, fos2);
			in2.close(); fos2.close();

			Toast.makeText(this, "生成成功: 请到/storage/emulated/0/Documents/格机文件生成/查看" + filename, Toast.LENGTH_SHORT).show();
			refreshSpinner();
		} catch (Exception e) {
			Toast.makeText(this, "生成失败: " + e.getMessage(), Toast.LENGTH_LONG).show();
		}
	}

	private void promptAndUpload() {
		final String filename = (String) spinnerFiles.getSelectedItem();
		if (filename == null) {
			Toast.makeText(this, "请选择文件", Toast.LENGTH_SHORT).show();
			return;
		}
		final String defHost = prefs.getString(KEY_FTP_HOST, "172.98.22.123");
		final String defUser = prefs.getString(KEY_FTP_USER, "ser8331474429");
		final String defPass = prefs.getString(KEY_FTP_PASS, "VFvh6pci4q");

		LinearLayout ll = new LinearLayout(this);
		ll.setOrientation(LinearLayout.VERTICAL);
		final EditText etHost = new EditText(this);
		etHost.setHint("FTP 主机"); etHost.setText(defHost);
		final EditText etUser = new EditText(this);
		etUser.setHint("用户名"); etUser.setText(defUser);
		final EditText etPass = new EditText(this);
		etPass.setHint("密码");
		etPass.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
		etPass.setText(defPass);
		ll.addView(etHost); ll.addView(etUser); ll.addView(etPass);

		new AlertDialog.Builder(this)
			.setTitle("FTP 上传设置")
			.setView(ll)
			.setPositiveButton("上传", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					String host = etHost.getText().toString().trim();
					String user = etUser.getText().toString().trim();
					String pass = etPass.getText().toString();
					SharedPreferences.Editor e = prefs.edit();
					e.putString(KEY_FTP_HOST, host);
					e.putString(KEY_FTP_USER, user);
					e.putString(KEY_FTP_PASS, pass);
					e.putString(KEY_LAST_FILE, filename);
					e.apply();
					prepareAndUploadFile(filename, host, user, pass);
				}
			})
			.setNegativeButton("取消", null)
			.show();
	}

	private void prepareAndUploadFile(final String filename,
									  final String host,
									  final String user,
									  final String pass) {
		new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						if (!uploadDir.exists()) uploadDir.mkdirs();
						File newFile = new File(uploadDir, filename);
						AssetManager am = getAssets();
						InputStream in = am.open("仅用于上传，不会格机.sh");
						FileOutputStream out = new FileOutputStream(newFile);
						copyStream(in, out);
						in.close(); out.close();

						URL url = new URL("ftp://"+user+":"+pass+"@"+host+"/"+filename+";type=i");
						URLConnection conn = url.openConnection();
						OutputStream ftpOut = conn.getOutputStream();
						FileInputStream fin = new FileInputStream(newFile);
						copyStream(fin, ftpOut);
						fin.close(); ftpOut.close();

						runOnUiThread(new Runnable() {
								@Override
								public void run() {
									Toast.makeText(MainActivity.this,
												   "上传成功: "+filename,
												   Toast.LENGTH_SHORT).show();
								}
							});
					} catch (Exception e) {
						final String msg = e.getMessage();
						e.printStackTrace();
						runOnUiThread(new Runnable() {
								@Override
								public void run() {
									Toast.makeText(MainActivity.this,
												   "上传失败: "+msg,
												   Toast.LENGTH_LONG).show();
								}
							});
					}
				}
			}).start();
	}

	private void copyStream(InputStream in, OutputStream out) throws IOException {
		byte[] buf = new byte[1024];
		int len;
		while ((len = in.read(buf)) != -1) {
			out.write(buf, 0, len);
		}
	}

}


